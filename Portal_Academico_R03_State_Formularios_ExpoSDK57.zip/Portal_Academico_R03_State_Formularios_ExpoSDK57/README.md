# Portal Acadêmico R03

Release com estado e interação.

Novos conceitos:
- useState
- useMemo
- TextInput
- Pressable com ações
- atualização dinâmica

Executar:

npm install

npx expo start
