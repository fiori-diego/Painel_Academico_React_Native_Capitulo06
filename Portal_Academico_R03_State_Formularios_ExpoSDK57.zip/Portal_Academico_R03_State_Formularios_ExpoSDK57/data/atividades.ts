export const atividadesIniciais = [
 {id:"1", titulo:"Estudar React Native", disciplina:"Mobile", concluida:false},
 {id:"2", titulo:"Criar componentes", disciplina:"Mobile", concluida:true}
];
