import { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { Text, View, StyleSheet } from "react-native";
import FormAtividade from "../components/FormAtividade";
import AtividadeItem from "../components/AtividadeItem";
import { useAtividades } from "../hooks/useAtividades";

export default function Home(){

const {atividades,pendentes,adicionar,alternar}=useAtividades();
const [texto,setTexto]=useState("");

return(
<SafeAreaView style={styles.container}>

<View style={styles.header}>
<Text style={styles.title}>Portal Acadêmico</Text>
<Text>Pendentes: {pendentes}</Text>
</View>

<View style={styles.content}>

<FormAtividade
valor={texto}
alterar={setTexto}
adicionar={()=>{
adicionar(texto);
setTexto("");
}}
/>

{atividades.map(item=>(
<AtividadeItem
key={item.id}
item={item}
onPress={()=>alternar(item.id)}
/>
))}

</View>
</SafeAreaView>
)
}

const styles=StyleSheet.create({
container:{flex:1,backgroundColor:"#f4f6f8"},
header:{padding:20,backgroundColor:"#202d74"},
title:{fontSize:26,color:"#fff",fontWeight:"700"},
content:{padding:20}
});
