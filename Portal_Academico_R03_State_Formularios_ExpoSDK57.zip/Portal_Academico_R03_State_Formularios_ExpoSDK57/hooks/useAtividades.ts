import { useMemo, useState } from "react";
import { atividadesIniciais } from "../data/atividades";

export function useAtividades(){

 const [atividades,setAtividades] = useState(atividadesIniciais);

 const pendentes = useMemo(
  ()=>atividades.filter(item=>!item.concluida).length,
  [atividades]
 );

 function adicionar(titulo:string){
  if(!titulo.trim()) return;

  setAtividades(lista=>[
   ...lista,
   {
    id:Date.now().toString(),
    titulo,
    disciplina:"Nova atividade",
    concluida:false
   }
  ]);
 }

 function alternar(id:string){
  setAtividades(lista=>
   lista.map(item=>
    item.id===id
    ? {...item, concluida:!item.concluida}
    : item
   )
  );
 }

 return {atividades,pendentes,adicionar,alternar};
}
