import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";

type Props={
 valor:string;
 alterar:(texto:string)=>void;
 adicionar:()=>void;
};

export default function FormAtividade({valor,alterar,adicionar}:Props){
return(
<View style={styles.container}>
<TextInput
style={styles.input}
value={valor}
placeholder="Nova atividade"
onChangeText={alterar}
/>

<Pressable style={styles.button} onPress={adicionar}>
<Text style={styles.text}>Adicionar</Text>
</Pressable>
</View>
)
}

const styles=StyleSheet.create({
container:{flexDirection:"row",gap:8,marginVertical:15},
input:{flex:1,backgroundColor:"#fff",padding:12,borderRadius:8},
button:{backgroundColor:"#202d74",padding:12,borderRadius:8},
text:{color:"#fff"}
});
