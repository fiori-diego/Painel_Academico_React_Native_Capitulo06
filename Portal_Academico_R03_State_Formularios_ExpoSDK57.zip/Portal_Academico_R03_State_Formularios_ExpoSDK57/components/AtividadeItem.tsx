import { Pressable, Text } from "react-native";

export default function AtividadeItem({item,onPress}:any){
return(
<Pressable onPress={onPress}>
<Text style={{fontSize:18,marginVertical:8}}>
{item.concluida?"✓":"○"} {item.titulo}
</Text>
</Pressable>
)
}
