# Código comentado R03

useState mantém dados da aplicação.

useMemo calcula valores derivados como atividades pendentes.

TextInput captura informações digitadas.

Pressable executa ações do usuário.

A mudança de estado provoca nova renderização.
