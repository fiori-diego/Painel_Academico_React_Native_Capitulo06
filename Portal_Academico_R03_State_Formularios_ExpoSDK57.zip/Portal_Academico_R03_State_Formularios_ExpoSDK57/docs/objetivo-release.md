# R03 Estado e formulários

Objetivo:
transformar uma interface estática em uma aplicação interativa.
