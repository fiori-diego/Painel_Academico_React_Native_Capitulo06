Commit 001
feat: criação do estado de atividades

Commit 002
feat: formulário de cadastro

Commit 003
feat: alteração de status

Commit 004
refactor: criação do hook useAtividades
