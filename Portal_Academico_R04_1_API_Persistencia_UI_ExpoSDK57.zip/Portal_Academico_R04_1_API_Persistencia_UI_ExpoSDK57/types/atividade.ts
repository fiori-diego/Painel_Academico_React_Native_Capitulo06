export type Atividade={
 id:string;
 titulo:string;
 disciplina:string;
 concluida:boolean;
};
