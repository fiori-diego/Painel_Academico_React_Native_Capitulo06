Commit 001 UI
Commit 002 Cards
Commit 003 Atualização API
Commit 004 Persistência