import {View,Text,StyleSheet} from 'react-native';

export default function CardResumo({titulo,valor}:any){
return <View style={styles.card}>
<Text>{titulo}</Text>
<Text style={styles.valor}>{valor}</Text>
</View>
}

const styles=StyleSheet.create({
card:{backgroundColor:'#fff',padding:20,borderRadius:12,margin:5},
valor:{fontSize:28,fontWeight:'700'}
});
