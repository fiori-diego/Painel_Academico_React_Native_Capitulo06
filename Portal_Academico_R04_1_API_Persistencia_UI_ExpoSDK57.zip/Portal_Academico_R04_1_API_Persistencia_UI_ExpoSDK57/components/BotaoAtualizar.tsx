import {Pressable,Text} from 'react-native';

export default function BotaoAtualizar({acao}:any){
return <Pressable onPress={acao}
style={{backgroundColor:'#202d74',padding:15,borderRadius:10}}>
<Text style={{color:'#fff',textAlign:'center'}}>
Atualizar dados
</Text>
</Pressable>
}
