import {View,Text,StyleSheet} from 'react-native';

export default function Header(){
return <View style={styles.header}>
<Text style={styles.titulo}>Portal Acadêmico</Text>
<Text style={styles.sub}>Bem-vindo, estudante 👋</Text>
</View>
}

const styles=StyleSheet.create({
header:{backgroundColor:'#202d74',padding:20},
titulo:{color:'#fff',fontSize:26,fontWeight:'700'},
sub:{color:'#fff',marginTop:8}
});
