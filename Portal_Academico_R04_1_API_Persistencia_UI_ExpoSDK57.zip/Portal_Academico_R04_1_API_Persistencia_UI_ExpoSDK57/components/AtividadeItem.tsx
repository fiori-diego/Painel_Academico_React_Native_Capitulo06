import {Text,View,StyleSheet} from 'react-native';

export default function AtividadeItem({item}:any){
return <View style={styles.item}>
<Text style={styles.texto}>
{item.concluida?'✓':'○'} {item.titulo}
</Text>
</View>
}

const styles=StyleSheet.create({
item:{backgroundColor:'#fff',padding:15,marginVertical:5,borderRadius:10},
texto:{fontSize:17}
});
