import {SafeAreaView} from 'react-native-safe-area-context';
import {View,Text,ScrollView,StyleSheet} from 'react-native';
import Header from '../components/Header';
import CardResumo from '../components/CardResumo';
import AtividadeItem from '../components/AtividadeItem';
import BotaoAtualizar from '../components/BotaoAtualizar';
import {useAtividades} from '../hooks/useAtividades';

export default function Home(){

const {atividades,loading,erro,atualizar}=useAtividades();

return <SafeAreaView style={styles.container}>
<ScrollView>
<Header/>

<View style={styles.cards}>
<CardResumo titulo="Disciplinas" valor="6"/>
<CardResumo titulo="Pendentes" valor={atividades.filter(a=>!a.concluida).length}/>
</View>

{loading && <Text>Carregando dados...</Text>}
{erro && <Text>{erro}</Text>}

{atividades.map(item=>
<AtividadeItem key={item.id} item={item}/>
)}

<BotaoAtualizar acao={atualizar}/>

</ScrollView>
</SafeAreaView>
}

const styles=StyleSheet.create({
container:{flex:1,backgroundColor:'#f4f6f8'},
cards:{flexDirection:'row',justifyContent:'center',marginVertical:20}
});
