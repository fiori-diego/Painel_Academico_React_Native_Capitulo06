import dados from '../data/mock-api.json';

export async function buscarAtividades(){
 await new Promise(resolve=>setTimeout(resolve,1000));
 return dados;
}
