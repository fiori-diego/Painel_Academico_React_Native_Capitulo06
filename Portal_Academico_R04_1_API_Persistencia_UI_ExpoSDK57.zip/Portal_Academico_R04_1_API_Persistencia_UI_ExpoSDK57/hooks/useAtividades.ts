import {useEffect,useState} from 'react';
import {buscarAtividades} from '../services/api';
import {lerDados,salvarDados} from '../storage/localStorage';

export function useAtividades(){

const [atividades,setAtividades]=useState<any[]>([]);
const [loading,setLoading]=useState(true);
const [erro,setErro]=useState('');

async function carregar(){

try{
 setErro('');
 setLoading(true);

 const cache=await lerDados();

 if(cache){
  setAtividades(cache);
 }

 const dados=await buscarAtividades();

 setAtividades(dados);
 await salvarDados(dados);

}catch{
 setErro('Erro ao carregar dados.');
}
finally{
 setLoading(false);
}

}

useEffect(()=>{carregar()},[]);

return {
 atividades,
 loading,
 erro,
 atualizar:carregar
};

}
