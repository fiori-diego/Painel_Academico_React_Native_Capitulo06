import AsyncStorage from '@react-native-async-storage/async-storage';

const CHAVE='portal-atividades';

export async function salvarDados(dados:any){
 await AsyncStorage.setItem(CHAVE,JSON.stringify(dados));
}

export async function lerDados(){
 const valor=await AsyncStorage.getItem(CHAVE);
 return valor ? JSON.parse(valor) : null;
}
