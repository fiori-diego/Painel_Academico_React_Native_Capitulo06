# Portal Acadêmico R04.1

Correção da R04 com interface completa.

Conceitos:
- API REST
- services
- hooks
- AsyncStorage
- loading
- componentes reutilizáveis

Executar:

npm install

npx expo start
