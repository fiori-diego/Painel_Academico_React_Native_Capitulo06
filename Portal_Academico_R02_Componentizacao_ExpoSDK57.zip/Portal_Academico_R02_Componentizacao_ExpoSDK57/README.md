# Portal Acadêmico - Release 02

## Componentização

Evolução da Release 01.

Novos conceitos:

- Componentes reutilizáveis;
- Props;
- Organização por responsabilidade.

Executar:

```bash
npm install
npx expo start
```

Estrutura:

components/
- Header
- CardResumo
- AtividadeItem

Próxima release:
R03 - Estado, formulários e interação.
