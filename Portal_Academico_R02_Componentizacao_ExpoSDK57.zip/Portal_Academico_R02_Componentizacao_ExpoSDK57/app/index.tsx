import { SafeAreaView } from "react-native-safe-area-context";
import { StyleSheet, Text, View, Pressable } from "react-native";

import Header from "../components/Header";
import CardResumo from "../components/CardResumo";
import AtividadeItem from "../components/AtividadeItem";

export default function HomeScreen(){

return(
<SafeAreaView style={styles.container}>

<Header />

<View style={styles.content}>

<Text style={styles.welcome}>
Olá, estudante! 👋
</Text>

<View style={styles.row}>
<CardResumo titulo="Disciplinas" valor={6}/>
<CardResumo titulo="Pendentes" valor={4}/>
</View>

<Text style={styles.section}>
Próximas atividades
</Text>

<AtividadeItem titulo="Estudar React Native" concluida={false}/>
<AtividadeItem titulo="Criar componentes" concluida={true}/>

<Pressable style={styles.button}>
<Text style={styles.buttonText}>Abrir portal</Text>
</Pressable>

</View>

</SafeAreaView>
);
}

const styles=StyleSheet.create({
container:{flex:1,backgroundColor:"#f4f6f8"},
content:{padding:20},
welcome:{fontSize:24,fontWeight:"700"},
row:{flexDirection:"row",marginTop:20,marginHorizontal:-6},
section:{marginTop:25,fontSize:18,fontWeight:"700"},
button:{marginTop:20,padding:15,borderRadius:10,backgroundColor:"#202d74",alignItems:"center"},
buttonText:{color:"#fff",fontWeight:"700"}
});
