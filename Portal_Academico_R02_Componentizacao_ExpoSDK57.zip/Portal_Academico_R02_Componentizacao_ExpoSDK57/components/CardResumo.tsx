import { StyleSheet, Text, View } from "react-native";

type Props = {
 titulo:string;
 valor:number;
};

export default function CardResumo({titulo,valor}:Props){
 return(
  <View style={styles.card}>
   <Text style={styles.titulo}>{titulo}</Text>
   <Text style={styles.valor}>{valor}</Text>
  </View>
 );
}

const styles=StyleSheet.create({
 card:{flex:1,padding:18,margin:6,borderRadius:12,backgroundColor:"#fff"},
 titulo:{color:"#68707c"},
 valor:{fontSize:28,fontWeight:"700",color:"#202d74"}
});
