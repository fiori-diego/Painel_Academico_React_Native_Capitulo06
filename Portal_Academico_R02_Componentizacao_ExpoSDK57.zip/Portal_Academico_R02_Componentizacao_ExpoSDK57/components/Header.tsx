import { StyleSheet, Text, View } from "react-native";

export default function Header(){
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Portal Acadêmico</Text>
      <Text style={styles.subtitle}>Release 02 - Componentização</Text>
    </View>
  );
}

const styles = StyleSheet.create({
 container:{padding:24,backgroundColor:"#202d74"},
 title:{color:"#fff",fontSize:26,fontWeight:"700"},
 subtitle:{color:"#dfe4ff",marginTop:5}
});
