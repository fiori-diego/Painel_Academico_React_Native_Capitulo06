import { StyleSheet, Text, View } from "react-native";

type Props={
 titulo:string;
 concluida:boolean;
};

export default function AtividadeItem({titulo,concluida}:Props){
 return(
  <View style={styles.item}>
   <Text style={concluida ? styles.done : styles.text}>
    {concluida ? "✓ " : "○ "}{titulo}
   </Text>
  </View>
 );
}

const styles=StyleSheet.create({
 item:{padding:14,backgroundColor:"#fff",borderRadius:10,marginTop:10},
 text:{fontSize:16},
 done:{fontSize:16,textDecorationLine:"line-through"}
});
