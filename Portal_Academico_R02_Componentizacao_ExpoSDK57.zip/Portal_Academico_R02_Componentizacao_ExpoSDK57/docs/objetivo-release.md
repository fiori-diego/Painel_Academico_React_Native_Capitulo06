# Release 02 - Componentização

Objetivo:

Evoluir uma tela única para uma arquitetura baseada em componentes React Native.

Competências:

- compreender props;
- criar componentes;
- separar responsabilidades.
