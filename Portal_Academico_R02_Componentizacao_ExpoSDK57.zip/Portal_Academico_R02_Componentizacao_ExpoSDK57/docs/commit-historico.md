# Histórico de commits

Commit 001
refactor: separação do Header

Commit 002
feat: criação do CardResumo

Commit 003
feat: criação do AtividadeItem

Commit 004
refactor: organização por componentes
