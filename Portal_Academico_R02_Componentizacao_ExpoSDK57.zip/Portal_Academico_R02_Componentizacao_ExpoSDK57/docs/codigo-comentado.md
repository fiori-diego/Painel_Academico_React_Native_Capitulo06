# Código comentado - Release 02

## Componentização

O arquivo index.tsx deixa de concentrar toda a interface.

Agora cada parte possui responsabilidade própria.

## Props

Exemplo:

<CardResumo titulo="Disciplinas" valor={6}/>

O componente recebe dados externos.

## Benefícios

- reutilização;
- manutenção facilitada;
- código organizado.
