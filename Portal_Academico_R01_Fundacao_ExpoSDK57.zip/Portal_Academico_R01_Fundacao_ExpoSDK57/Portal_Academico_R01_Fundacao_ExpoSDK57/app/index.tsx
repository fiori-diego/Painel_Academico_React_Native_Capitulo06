import { Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function HomeScreen(){

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Portal Acadêmico</Text>
        <Text style={styles.subtitle}>Projeto React Native</Text>
      </View>

      <View style={styles.content}>
        <Text style={styles.welcome}>Olá, estudante! 👋</Text>

        <Text style={styles.description}>
          Bem-vindo ao aplicativo acadêmico desenvolvido com React Native.
        </Text>

        <Pressable style={styles.button}>
          <Text style={styles.buttonText}>Explorar portal</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
 container:{flex:1,backgroundColor:"#f4f6f8"},
 header:{padding:24,backgroundColor:"#202d74"},
 title:{color:"#fff",fontSize:28,fontWeight:"700"},
 subtitle:{color:"#dfe4ff",marginTop:5},
 content:{padding:20},
 welcome:{fontSize:24,fontWeight:"700"},
 description:{marginTop:12,fontSize:16,lineHeight:24},
 button:{marginTop:25,padding:15,borderRadius:10,backgroundColor:"#202d74",alignItems:"center"},
 buttonText:{color:"#fff",fontWeight:"700"}
});
