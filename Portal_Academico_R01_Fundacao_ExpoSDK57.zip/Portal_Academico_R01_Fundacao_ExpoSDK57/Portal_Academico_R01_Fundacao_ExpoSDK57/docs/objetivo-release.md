# Release 01 - Fundação

Objetivo: apresentar a estrutura inicial de uma aplicação React Native.

Conceitos:
- Expo;
- Expo Router;
- componentes;
- JSX;
- estilos.
