# Histórico de commits

## Commit 001

chore: criação inicial do projeto Expo

## Commit 002

feat: criação da tela inicial do Portal Acadêmico

## Commit 003

style: organização visual da interface
