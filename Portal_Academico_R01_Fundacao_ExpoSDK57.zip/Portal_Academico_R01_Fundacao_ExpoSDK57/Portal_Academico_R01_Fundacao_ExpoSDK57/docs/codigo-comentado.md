# Código comentado

## Importações

`View` organiza elementos visuais.

`Text` apresenta textos.

`Pressable` cria elementos interativos.

`SafeAreaView` protege áreas sensíveis do dispositivo.

## HomeScreen

É o componente principal da primeira tela.

O retorno JSX descreve a interface que será renderizada.

## StyleSheet

Organiza os estilos da aplicação.
