# Portal Acadêmico - Release 01

## Fundação do aplicativo

Projeto desenvolvido para o Capítulo 6 - Desenvolvimento de aplicações React Native completas.

## Ambiente

- Expo SDK 57
- React Native
- TypeScript
- Expo Router

## Executar

```bash
npm install
npx expo start
```

Abra o QR Code utilizando o Expo Go.

## Objetivos desta release

- Criar projeto Expo;
- compreender estrutura de pastas;
- utilizar componentes básicos;
- executar aplicativo no dispositivo.

## Próximas releases

R02 - Componentização  
R03 - Estado e formulários  
R04 - API e persistência  
R05 - Recursos avançados  
R06 - Produto final
