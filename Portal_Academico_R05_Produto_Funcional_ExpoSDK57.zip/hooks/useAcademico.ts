import { useCallback, useEffect, useState } from "react";
import { Atividade, Disciplina, listarAtividades, listarDisciplinas } from "../services/api";

// Hook concentra carregamento e estado dos dados acadêmicos.
export function useAcademico() {
  const [disciplinas, setDisciplinas] = useState<Disciplina[]>([]);
  const [atividades, setAtividades] = useState<Atividade[]>([]);
  const [carregando, setCarregando] = useState(true);

  const carregar = useCallback(async () => {
    setCarregando(true);
    const [d, a] = await Promise.all([listarDisciplinas(), listarAtividades()]);
    setDisciplinas(d);
    setAtividades(a);
    setCarregando(false);
  }, []);

  useEffect(() => { carregar(); }, [carregar]);

  const concluirAtividade = (id: number) => {
    setAtividades((lista) => lista.map((item) => item.id === id ? { ...item, concluida: !item.concluida } : item));
  };

  const reiniciarAtividades = () => {
    setAtividades((lista) => lista.map((item) => ({ ...item, concluida: false })));
  };

  return { disciplinas, atividades, carregando, concluirAtividade, reiniciarAtividades, recarregar: carregar };
}