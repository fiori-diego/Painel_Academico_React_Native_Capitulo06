export type Disciplina = {
  id: number;
  nome: string;
  professor: string;
  periodo: string;
  nota: number;
};

export type Atividade = {
  id: number;
  titulo: string;
  disciplina: string;
  prazo: string;
  concluida: boolean;
};

// O service simula uma API REST para que a aplicação seja executável sem backend.
// Em uma API real, este bloco pode ser substituído por fetch(BASE_URL + ...).
export async function listarDisciplinas(): Promise<Disciplina[]> {
  await new Promise((resolve) => setTimeout(resolve, 300));
  return [
    { id: 1, nome: "Desenvolvimento Mobile", professor: "Prof. Diego Fiori", periodo: "2026/2", nota: 8.5 },
    { id: 2, nome: "Banco de Dados II", professor: "Prof. Renato", periodo: "2026/2", nota: 9.0 },
    { id: 3, nome: "Engenharia de Software", professor: "Prof. Marcílio", periodo: "2026/2", nota: 8.2 },
    { id: 4, nome: "Desenvolvimento Web", professor: "Prof. Carlos", periodo: "2026/2", nota: 8.0 },
    { id: 5, nome: "Sistemas Operacionais", professor: "Prof. Mauricio", periodo: "2026/2", nota: 8.7 },
    { id: 6, nome: "Projeto Integrador", professor: "Prof. Patricia", periodo: "2026/2", nota: 8.9 },
  ];
}

export async function listarAtividades(): Promise<Atividade[]> {
  await new Promise((resolve) => setTimeout(resolve, 350));
  return [
    { id: 1, titulo: "Entregar projeto final", disciplina: "Desenvolvimento Mobile", prazo: "15/10/2026", concluida: false },
    { id: 2, titulo: "Prova de Banco de Dados", disciplina: "Banco de Dados II", prazo: "22/10/2026", concluida: false },
    { id: 3, titulo: "Seminário", disciplina: "Engenharia de Software", prazo: "28/10/2026", concluida: false },
    { id: 4, titulo: "Lista de exercícios", disciplina: "Desenvolvimento Web", prazo: "30/10/2026", concluida: false },
  ];
}