// Valores visuais centralizados para manter consistência entre as telas.
export const colors = {
  primary: "#24357A",
  primaryLight: "#EAF0FF",
  background: "#F4F6FA",
  surface: "#FFFFFF",
  text: "#17204A",
  muted: "#626A7A",
  border: "#E2E5EC",
  success: "#0B8F5A",
  warning: "#D97706",
  danger: "#C62828",
};