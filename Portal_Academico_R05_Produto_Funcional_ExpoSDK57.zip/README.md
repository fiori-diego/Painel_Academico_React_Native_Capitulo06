# Portal Acadêmico — Release 5.1 funcional

Esta versão corresponde à proposta visual/funcional da Release 5: Dashboard, navegação por abas, disciplinas, atividades, perfil, componentes reutilizáveis, dados simulados por service/hook e estados de carregamento.

## Execução

```powershell
npm install
npx expo start -c
```

Se o projeto já tiver uma instalação antiga:

```powershell
Remove-Item -Recurse -Force node_modules
Remove-Item -Force package-lock.json -ErrorAction SilentlyContinue
npm install
npx expo start -c
```

## Interações

- Toque nas abas inferiores para navegar.
- Toque em uma atividade para concluir/desconcluir.
- Use “Concluir uma atividade” no Dashboard.
- Use “Reiniciar contador” para restaurar todas as atividades como pendentes.
- A lista de disciplinas e atividades é carregada por um hook que chama um service local simulado.
