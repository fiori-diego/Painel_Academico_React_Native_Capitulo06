import { StyleSheet, Text, View } from "react-native";
import { colors } from "../constants/theme";

type Props = { titulo: string; valor: string; detalhe?: string; icone?: string };

// Cartão reutilizável para os indicadores do Dashboard.
export default function CardResumo({ titulo, valor, detalhe, icone }: Props) {
  return (
    <View style={styles.card}>
      <Text style={styles.icon}>{icone}</Text>
      <Text style={styles.titulo}>{titulo}</Text>
      <Text style={styles.valor}>{valor}</Text>
      {detalhe ? <Text style={styles.detalhe}>{detalhe}</Text> : null}
    </View>
  );
}
const styles = StyleSheet.create({
  card: { width: "48%", minHeight: 138, backgroundColor: colors.surface, borderRadius: 18, padding: 16, marginBottom: 12 },
  icon: { fontSize: 27, marginBottom: 8 },
  titulo: { fontSize: 15, color: colors.text, fontWeight: "700" },
  valor: { marginTop: 8, fontSize: 28, fontWeight: "800", color: colors.text },
  detalhe: { marginTop: 2, color: colors.muted },
});