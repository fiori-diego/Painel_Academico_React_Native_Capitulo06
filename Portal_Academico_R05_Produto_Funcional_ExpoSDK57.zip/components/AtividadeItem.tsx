import { Pressable, StyleSheet, Text, View } from "react-native";
import { colors } from "../constants/theme";
import { Atividade } from "../services/api";

// Item reutilizável e interativo da lista de atividades.
export default function AtividadeItem({ atividade, onPress }: { atividade: Atividade; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
      <View style={styles.row}>
        <View style={styles.content}>
          <Text style={[styles.titulo, atividade.concluida && styles.concluida]}>{atividade.titulo}</Text>
          <Text style={styles.disciplina}>{atividade.disciplina}</Text>
          <Text style={styles.prazo}>Prazo: {atividade.prazo}</Text>
        </View>
        <View style={[styles.badge, atividade.concluida ? styles.badgeDone : styles.badgePending]}>
          <Text style={styles.badgeText}>{atividade.concluida ? "✓" : "!"}</Text>
        </View>
      </View>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  card: { backgroundColor: colors.surface, borderRadius: 15, padding: 16, marginBottom: 10 },
  pressed: { opacity: 0.75 },
  row: { flexDirection: "row", alignItems: "center" },
  content: { flex: 1 },
  titulo: { fontSize: 16, fontWeight: "800", color: colors.text },
  concluida: { textDecorationLine: "line-through", color: colors.muted },
  disciplina: { marginTop: 5, color: colors.muted },
  prazo: { marginTop: 4, color: colors.primary, fontWeight: "600" },
  badge: { width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center" },
  badgeDone: { backgroundColor: "#DDF6EA" },
  badgePending: { backgroundColor: "#FFF0D8" },
  badgeText: { fontWeight: "900", color: colors.text },
});