import { StyleSheet, Text, View } from "react-native";
import { colors } from "../constants/theme";

// Cabeçalho reutilizável para as telas principais.
export default function Header() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Portal Acadêmico</Text>
      <Text style={styles.subtitle}>Olá, estudante 👋</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { marginBottom: 18 },
  title: { fontSize: 28, fontWeight: "800", color: colors.text },
  subtitle: { marginTop: 4, fontSize: 16, color: colors.muted },
});