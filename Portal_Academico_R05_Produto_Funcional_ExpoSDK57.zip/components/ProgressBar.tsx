import { StyleSheet, View } from "react-native";
import { colors } from "../constants/theme";

export default function ProgressBar({ value }: { value: number }) {
  // O valor é limitado entre 0 e 100 para evitar uma barra inválida.
  const percentual = Math.max(0, Math.min(100, value));
  return <View style={styles.track}><View style={[styles.fill, { width: `${percentual}%` }]} /></View>;
}
const styles = StyleSheet.create({
  track: { height: 12, backgroundColor: "#DDE2EF", borderRadius: 8, overflow: "hidden" },
  fill: { height: "100%", backgroundColor: colors.primary, borderRadius: 8 },
});