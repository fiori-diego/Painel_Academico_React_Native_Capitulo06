# Como executar a Release 5.1

1. Instale Node.js compatível com o projeto.
2. Extraia o ZIP.
3. Abra PowerShell na pasta do projeto.
4. Execute `npm install`.
5. Execute `npx expo start -c`.
6. Abra no Expo Go ou use o emulador.

### Se aparecer erro de dependências

Não use `--force` inicialmente. Faça instalação limpa:

```powershell
Remove-Item -Recurse -Force node_modules
Remove-Item -Force package-lock.json -ErrorAction SilentlyContinue
npm install
npx expo start -c
```

### O que deve funcionar

A barra inferior deve abrir quatro telas reais: Início, Disciplinas, Atividades e Perfil. O Dashboard também possui cartões, progresso, lista de atividades e botões interativos.
