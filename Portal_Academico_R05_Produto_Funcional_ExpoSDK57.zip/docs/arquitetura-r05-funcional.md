# Arquitetura da Release 5.1

```text
Tela
 ↓
Hook useAcademico
 ↓
Service
 ↓
Dados simulados / futura API REST
```

O objetivo é consolidar navegação, componentes, estado, listas e camada de serviço em uma aplicação funcional.
