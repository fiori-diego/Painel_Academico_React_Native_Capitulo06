import { FlatList, StyleSheet, Text, View } from "react-native";
import AtividadeItem from "../../components/AtividadeItem";
import { useAcademico } from "../../hooks/useAcademico";
import { colors } from "../../constants/theme";

export default function Atividades() {
  const { atividades, carregando, concluirAtividade } = useAcademico();
  return (
    <FlatList
      data={atividades}
      keyExtractor={(item) => String(item.id)}
      contentContainerStyle={styles.container}
      ListHeaderComponent={<View><Text style={styles.title}>Atividades</Text><Text style={styles.subtitle}>Toque em uma atividade para marcar como concluída.</Text></View>}
      ListEmptyComponent={carregando ? <Text>Carregando...</Text> : <Text>Nenhuma atividade encontrada.</Text>}
      renderItem={({ item }) => <AtividadeItem atividade={item} onPress={() => concluirAtividade(item.id)} />}
    />
  );
}
const styles = StyleSheet.create({ container: { padding: 20, backgroundColor: colors.background, flexGrow: 1 }, title: { fontSize: 30, fontWeight: "800", color: colors.text, marginBottom: 5 }, subtitle: { color: colors.muted, marginBottom: 18 } });