import { FlatList, StyleSheet, Text, View } from "react-native";
import { useAcademico } from "../../hooks/useAcademico";
import { colors } from "../../constants/theme";

export default function Disciplinas() {
  const { disciplinas, carregando } = useAcademico();
  return (
    <FlatList
      data={disciplinas}
      keyExtractor={(item) => String(item.id)}
      contentContainerStyle={styles.container}
      ListHeaderComponent={<View><Text style={styles.title}>Disciplinas</Text><Text style={styles.subtitle}>Componentes curriculares do período atual.</Text></View>}
      ListEmptyComponent={carregando ? <Text>Carregando...</Text> : <Text>Nenhuma disciplina encontrada.</Text>}
      renderItem={({ item }) => (
        <View style={styles.card}>
          <Text style={styles.nome}>{item.nome}</Text>
          <Text style={styles.professor}>{item.professor}</Text>
          <View style={styles.row}><Text style={styles.periodo}>{item.periodo}</Text><Text style={styles.nota}>Nota {item.nota.toFixed(1)}</Text></View>
        </View>
      )}
    />
  );
}
const styles = StyleSheet.create({ container: { padding: 20, backgroundColor: colors.background, flexGrow: 1 }, title: { fontSize: 30, fontWeight: "800", color: colors.text }, subtitle: { marginTop: 5, marginBottom: 18, color: colors.muted }, card: { backgroundColor: colors.surface, padding: 18, borderRadius: 16, marginBottom: 10 }, nome: { fontSize: 18, fontWeight: "800", color: colors.text }, professor: { marginTop: 5, color: colors.muted }, row: { marginTop: 12, flexDirection: "row", justifyContent: "space-between" }, periodo: { color: colors.primary, fontWeight: "700" }, nota: { color: colors.success, fontWeight: "800" } });