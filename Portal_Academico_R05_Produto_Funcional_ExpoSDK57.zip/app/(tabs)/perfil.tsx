import { StyleSheet, Text, View } from "react-native";
import { colors } from "../../constants/theme";

export default function Perfil() {
  return (
    <View style={styles.container}>
      <View style={styles.avatar}><Text style={styles.avatarText}>ES</Text></View>
      <Text style={styles.name}>Estudante</Text>
      <Text style={styles.email}>estudante@portal.edu.br</Text>
      <View style={styles.card}>
        <Text style={styles.label}>Curso</Text><Text style={styles.value}>Engenharia de Computacao</Text>
        <Text style={styles.label}>Período</Text><Text style={styles.value}>10º semestre</Text>
        <Text style={styles.label}>Situação</Text><Text style={styles.value}>Regular</Text>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({ container: { flex: 1, alignItems: "center", padding: 24, backgroundColor: colors.background }, avatar: { width: 94, height: 94, borderRadius: 47, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" }, avatarText: { color: "#FFF", fontSize: 28, fontWeight: "800" }, name: { marginTop: 15, fontSize: 25, fontWeight: "800", color: colors.text }, email: { marginTop: 4, color: colors.muted }, card: { width: "100%", backgroundColor: colors.surface, borderRadius: 18, padding: 20, marginTop: 24 }, label: { marginTop: 9, color: colors.muted, fontSize: 13 }, value: { marginTop: 3, fontSize: 17, fontWeight: "700", color: colors.text } });