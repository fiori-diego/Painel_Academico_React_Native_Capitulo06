import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import Header from "../../components/Header";
import CardResumo from "../../components/CardResumo";
import ProgressBar from "../../components/ProgressBar";
import AtividadeItem from "../../components/AtividadeItem";
import { useAcademico } from "../../hooks/useAcademico";
import { colors } from "../../constants/theme";

// Dashboard integra os módulos e apresenta os principais indicadores.
export default function Dashboard() {
  const { disciplinas, atividades, carregando, concluirAtividade, reiniciarAtividades } = useAcademico();
  const pendentes = atividades.filter((item) => !item.concluida).length;
  const concluidas = atividades.length - pendentes;
  const progresso = atividades.length ? Math.round((concluidas / atividades.length) * 100) : 0;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Header />
      <View style={styles.hero}>
        <Text style={styles.heroTitle}>Olá, Estudante!</Text>
        <Text style={styles.heroText}>Acompanhe seu desempenho e suas atividades acadêmicas.</Text>
      </View>

      <View style={styles.grid}>
        <CardResumo titulo="Disciplinas" valor={String(disciplinas.length || 6)} detalhe="matriculadas" icone="📚" />
        <CardResumo titulo="Pendentes" valor={String(pendentes)} detalhe="atividades" icone="📝" />
        <CardResumo titulo="Nota média" valor="8,5" detalhe="desempenho" icone="⭐" />
        <CardResumo titulo="Frequência" valor="92%" detalhe="presença" icone="📊" />
      </View>

      <View style={styles.progressBox}>
        <View style={styles.rowBetween}><Text style={styles.sectionTitle}>Meu progresso</Text><Text style={styles.percent}>{progresso}%</Text></View>
        <ProgressBar value={progresso} />
      </View>

      <View style={styles.rowBetween}>
        <Text style={styles.sectionTitle}>Próximas atividades</Text>
        <Text style={styles.link}>Ver todas ›</Text>
      </View>

      {carregando ? <Text style={styles.muted}>Carregando dados...</Text> : null}
      {!carregando && atividades.slice(0, 3).map((item) => <AtividadeItem key={item.id} atividade={item} onPress={() => concluirAtividade(item.id)} />)}

      <Pressable style={styles.primaryButton} onPress={() => {
        const primeira = atividades.find((item) => !item.concluida);
        if (primeira) concluirAtividade(primeira.id);
      }}>
        <Text style={styles.primaryButtonText}>Concluir uma atividade</Text>
      </Pressable>
      <Pressable style={styles.secondaryButton} onPress={reiniciarAtividades}>
        <Text style={styles.secondaryButtonText}>Reiniciar contador</Text>
      </Pressable>

      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>Integração dos módulos</Text>
        <Text style={styles.infoText}>Dashboard, disciplinas, atividades e perfil utilizam a mesma estrutura de navegação e componentes reutilizáveis.</Text>
      </View>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: colors.background, paddingBottom: 40 },
  hero: { backgroundColor: colors.primary, borderRadius: 20, padding: 22, marginBottom: 18 },
  heroTitle: { color: "#FFF", fontSize: 24, fontWeight: "800" },
  heroText: { color: "#E8ECFF", marginTop: 6, lineHeight: 21 },
  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  progressBox: { backgroundColor: colors.surface, borderRadius: 18, padding: 18, marginBottom: 18 },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  sectionTitle: { fontSize: 19, fontWeight: "800", color: colors.text },
  percent: { fontWeight: "800", color: colors.primary },
  link: { color: colors.primary, fontWeight: "700" },
  muted: { color: colors.muted, marginBottom: 10 },
  primaryButton: { backgroundColor: colors.primary, borderRadius: 14, padding: 16, alignItems: "center", marginTop: 8 },
  primaryButtonText: { color: "#FFF", fontSize: 16, fontWeight: "800" },
  secondaryButton: { backgroundColor: colors.surface, borderRadius: 14, padding: 16, alignItems: "center", marginTop: 10 },
  secondaryButtonText: { color: colors.text, fontSize: 16, fontWeight: "700" },
  infoCard: { marginTop: 18, backgroundColor: colors.surface, borderRadius: 18, padding: 18 },
  infoTitle: { fontSize: 18, fontWeight: "800", color: colors.text },
  infoText: { marginTop: 6, color: colors.muted, lineHeight: 21 },
});