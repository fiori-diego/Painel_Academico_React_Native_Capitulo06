import { Stack } from "expo-router";

// O layout raiz entrega a navegação por rotas ao grupo de abas.
export default function RootLayout() {
  return (
    <Stack>
      {/* O grupo de abas possui seu próprio layout. */}
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
    </Stack>
  );
}